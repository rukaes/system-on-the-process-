
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author PC
 */
public class records extends javax.swing.JFrame {

    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;

    /**
     * Creates new form records
     */
    public records() {
        initComponents();

        jtfsearch.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                performSearch();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                performSearch();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                // Not used when dealing with plain text documents
            }
        });
    }

    private void performSearch() {
        String searchText = jtfsearch.getText();
        DefaultTableModel tableModel = (DefaultTableModel) record_tbl.getModel();
        tableModel.setRowCount(0);

        try {
            String sql = "SELECT DISTINCT * FROM record_tbl "
                    + "WHERE `LRN` LIKE ? OR `Name` LIKE ? OR `student_section` LIKE ?  OR `Date` LIKE ? "
                    + "OR `Time_in` LIKE ? OR `status1` LIKE ? OR `Subjects1` LIKE ? " 
                    + "OR `Time_in2` LIKE ? OR `status2` LIKE ? OR `Subjects2` LIKE ? OR `Time_in3` LIKE ? "
                    + "OR `status3` LIKE ? OR `Subjects3` LIKE ? OR `Time_in4` LIKE ? OR `status4` LIKE ? "
                    + "OR `Subjects4` LIKE ? OR `Time_in5` LIKE ? OR `status5` LIKE ? OR `Subjects5` LIKE ? "
                    + "OR `Time_in6` LIKE ? OR `status6` LIKE ? OR `Subjects6` LIKE ? OR `Time_in7` LIKE ? "
                    + "OR `status7` LIKE ? OR `Subjects7` LIKE ?";

            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/attend_db", "root", "");
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, "%" + searchText + "%");
            stmt.setString(2, "%" + searchText + "%");
            stmt.setString(3, "%" + searchText + "%");
            stmt.setString(4, "%" + searchText + "%");
            stmt.setString(5, "%" + searchText + "%");
            stmt.setString(6, "%" + searchText + "%");
            stmt.setString(7, "%" + searchText + "%");
            stmt.setString(8, "%" + searchText + "%");
            stmt.setString(9, "%" + searchText + "%");
            stmt.setString(10, "%" + searchText + "%");
            stmt.setString(11, "%" + searchText + "%");
            stmt.setString(12, "%" + searchText + "%");
            stmt.setString(13, "%" + searchText + "%");
            stmt.setString(14, "%" + searchText + "%");
            stmt.setString(15, "%" + searchText + "%");
            stmt.setString(16, "%" + searchText + "%");
            stmt.setString(17, "%" + searchText + "%");
            stmt.setString(18, "%" + searchText + "%");
            stmt.setString(19, "%" + searchText + "%");
            stmt.setString(20, "%" + searchText + "%");
            stmt.setString(21, "%" + searchText + "%");
            stmt.setString(22, "%" + searchText + "%");
            stmt.setString(23, "%" + searchText + "%");
            stmt.setString(24, "%" + searchText + "%");
            stmt.setString(25, "%" + searchText + "%");
            ResultSet rs = stmt.executeQuery();

            // Clear existing data in JTable
            // Add search results to JTable
            while (rs.next()) {
                String lrn = rs.getString("LRN");
                String name = rs.getString("Name");
                
                String sec = rs.getString("student_section");
                String date = rs.getString("Date");
                String entry = rs.getString("Time_in");
                String sat1 = rs.getString("status1");
                String sub1 = rs.getString("Subjects1");

                String entry2 = rs.getString("Time_in2");
                String sat2 = rs.getString("status2");
                String sub2 = rs.getString("Subjects2");

                String entry3 = rs.getString("Time_in3");
                String sat3 = rs.getString("status3");
                String sub3 = rs.getString("Subjects3");

                String entry4 = rs.getString("Time_in4");
                String sat4 = rs.getString("status4");
                String sub4 = rs.getString("Subjects4");

                String entry5 = rs.getString("Time_in5");
                String sat5 = rs.getString("status5");
                String sub5 = rs.getString("Subjects5");

                String entry6 = rs.getString("Time_in6");
                String sat6 = rs.getString("status6");
                String sub6 = rs.getString("Subjects6");

                String entry7 = rs.getString("Time_in7");
                String sat7 = rs.getString("status7");
                String sub7 = rs.getString("Subjects7");

                tableModel.addRow(new Object[]{name, date, entry, sec, sat1, sub1, entry2, sat2, sub2, entry3, sat3, sub3, entry4, sat4, sub4, entry5, sat5, sub5, entry6, sat6, sub6, entry7, sat7, sub7});
            }

            // Close database connection
            rs.close();
            stmt.close();
            con.close();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jtfsearch = new javax.swing.JTextField();
        SearchButton = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        DeleteButton = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jPanel9 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        record_tbl = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        ROAbtn = new javax.swing.JButton();
        backbtn = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(102, 0, 153));

        jPanel3.setBackground(new java.awt.Color(255, 153, 153));

        jtfsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtfsearchActionPerformed(evt);
            }
        });

        SearchButton.setBackground(new java.awt.Color(255, 255, 255));
        SearchButton.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        SearchButton.setForeground(new java.awt.Color(204, 0, 204));
        SearchButton.setText("Search");
        SearchButton.setFocusable(false);
        SearchButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchButtonActionPerformed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton1.setForeground(new java.awt.Color(204, 0, 204));
        jButton1.setText("COUNT");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        DeleteButton.setBackground(new java.awt.Color(255, 255, 255));
        DeleteButton.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        DeleteButton.setForeground(new java.awt.Color(153, 0, 153));
        DeleteButton.setText("Delete");
        DeleteButton.setFocusable(false);
        DeleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteButtonActionPerformed(evt);
            }
        });

        record_tbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "NAME", "SECTION", "DATE", "time-in", "STATUS", "SUBJECT", "time-in2", "STATUS", "SUBJECT", "time-in3", "STATUS", "SUBJECT", "time-in4", "STATUS", "SUBJECT", "time-in5", "STATUS", "SUBJECT", "time-in6", "STATUS", "SUBJECTS", "time-in7", "STATUS", "SUBJECTS"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                true, true, true, true, false, true, true, true, true, true, true, true, true, true, false, true, true, true, true, true, true, true, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        record_tbl.setGridColor(new java.awt.Color(153, 0, 153));
        jScrollPane3.setViewportView(record_tbl);
        if (record_tbl.getColumnModel().getColumnCount() > 0) {
            record_tbl.getColumnModel().getColumn(1).setResizable(false);
            record_tbl.getColumnModel().getColumn(6).setResizable(false);
            record_tbl.getColumnModel().getColumn(9).setResizable(false);
            record_tbl.getColumnModel().getColumn(17).setResizable(false);
        }

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 1376, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 364, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 79, Short.MAX_VALUE))
        );

        jScrollPane2.setViewportView(jPanel9);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel4.setText("ICT-12-B");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 1102, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                                .addGap(26, 26, 26)
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                                .addComponent(jtfsearch, javax.swing.GroupLayout.PREFERRED_SIZE, 299, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(SearchButton, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addComponent(DeleteButton, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(13, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jtfsearch, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SearchButton, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addGap(11, 11, 11))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(DeleteButton, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel2.setBackground(new java.awt.Color(255, 153, 153));

        jLabel1.setFont(new java.awt.Font("Yu Mincho", 1, 24)); // NOI18N
        jLabel1.setText("BAGUIO CITY NATIONALSCIENCE HIGH SCHOOL");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setText("Attendance");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(240, 240, 240))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(491, 491, 491))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(74, 74, 74)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGap(21, 21, 21))
        );

        ROAbtn.setBackground(new java.awt.Color(255, 153, 153));
        ROAbtn.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        ROAbtn.setText("R,O,A");
        ROAbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ROAbtnActionPerformed(evt);
            }
        });

        backbtn.setBackground(new java.awt.Color(255, 153, 153));
        backbtn.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        backbtn.setText("Previous 1 page");
        backbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backbtnActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Report on Attendance here");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(backbtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ROAbtn)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(backbtn)
                    .addComponent(ROAbtn)
                    .addComponent(jLabel2))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void DeleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteButtonActionPerformed
        int p = JOptionPane.showConfirmDialog(null, "Do you want to delete?", "DELETE", JOptionPane.YES_NO_OPTION);
        if (p == 0) {
            try {
                String sql = "DELETE FROM `record_tbl` WHERE `LRN` = ?";
                // String sql = "DELETE FROM `record_tbl` `LRN` = ?";
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/attend_db", "root", "");
                pst = con.prepareStatement(sql);

                pst.setString(1, jtfsearch.getText());
                pst.executeUpdate();

                JOptionPane.showMessageDialog(null, "Deleted Successfully");

            } catch (SQLException | HeadlessException e) {
                JOptionPane.showMessageDialog(null, e);
            }

        }
        showtabledata();
    }//GEN-LAST:event_DeleteButtonActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/attend_db", "root", "");
            PreparedStatement pst = con.prepareStatement("SELECT COUNT(*) FROM record_tbl WHERE LRN = ? AND (status1 = 'absent' OR status2 = 'absent' OR status3 = 'absent' OR status4 = 'absent' OR status5 = 'absent' OR status6 = 'absent' OR status7 = 'absent')");

            pst.setString(1, jtfsearch.getText());
            ResultSet rs = pst.executeQuery();
            rs.next();
            int numAbsent = rs.getInt(1);

            pst = con.prepareStatement("SELECT COUNT(*) FROM record_tbl WHERE LRN = ? AND (status1 = 'late' OR status2 = 'late' OR status3 = 'late' OR status4 = 'late' OR status5 = 'late' OR status6 = 'late' OR status7 = 'late')");
            pst.setString(1, jtfsearch.getText());
            rs = pst.executeQuery();
            rs.next();
            int numLate = rs.getInt(1);

            pst = con.prepareStatement("SELECT COUNT(*) FROM record_tbl WHERE LRN = ? AND (status1 = 'present' OR status2 = 'present' OR status3 = 'present' OR status4 = 'present' OR status5 = 'present' OR status6 = 'present' OR status7 = 'present')");
            pst.setString(1, jtfsearch.getText());
            rs = pst.executeQuery();
            rs.next();
            int numPresent = rs.getInt(1);

            JOptionPane.showMessageDialog(null, "Absent: " + numAbsent + "\nLate: " + numLate + "\nPresent: " + numPresent);

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void SearchButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchButtonActionPerformed

        //        String searchText = jtfidno.getText();
        //        DefaultTableModel tableModel = (DefaultTableModel) Jtable.getModel();
        //        tableModel.setRowCount(0);
        //
        //        try{
        //            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/attendance_monitoring","root","");
        //            String sql = "SELECT * FROM `record_tbl` WHERE `LRN` LIKE ?";
        //            PreparedStatement stmt = con.prepareStatement(sql);
        //            stmt.setString(1, "%" + searchText + "%");
        //            ResultSet rs = stmt.executeQuery();
        //
        //            // Clear existing data in JTable
        //
        //            // Add search results to JTable
        //            while (rs.next()) {
        //                int qrId = rs.getInt("LRN");
        //                //int slot = rs.getInt("slot");
        //                String name = rs.getString("Name");
        //                String timein = rs.getString("Time_In");
        //                String timeout = rs.getString("Time_Out");
        //                String date = rs.getString("Date");
        //                  String section = rs.getString("student_section");
        //                String status = rs.getString("status");
        //
        //                tableModel.addRow(new Object[] { qrId, name, timein,timeout,date,section,status });
        //            }
        //
        //            // Close database connection
        //            rs.close();
        //            stmt.close();
        //            con.close();
        //
        //            //JOptionPane.showMessageDialog(null, "no result found");
        //
        //
        //        } catch (Exception ex) {
        //            ex.printStackTrace();
        //            JOptionPane.showMessageDialog(null,ex);
        //        }
        performSearch();
    }//GEN-LAST:event_SearchButtonActionPerformed

    private void jtfsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtfsearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtfsearchActionPerformed

    private void backbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backbtnActionPerformed
        // TODO add your handling code here:
        dispose();
        main r = new main();
        r.setVisible(true);
    }//GEN-LAST:event_backbtnActionPerformed

    private void ROAbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ROAbtnActionPerformed
        // TODO add your handling code here:
        dispose();
        reportreport v = new reportreport();
        v.setVisible(true);
    }//GEN-LAST:event_ROAbtnActionPerformed

    private void showtabledata() {
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/attend_db", "root", "");
            String sql = "SELECT * FROM record_tbl";
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            record_tbl.setModel(DbUtils.resultSetToTableModel(rs));

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(records.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(records.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(records.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(records.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new records().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton DeleteButton;
    private javax.swing.JButton ROAbtn;
    private javax.swing.JButton SearchButton;
    private javax.swing.JButton backbtn;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextField jtfsearch;
    private javax.swing.JTable record_tbl;
    // End of variables declaration//GEN-END:variables
}
